import { Outlet, NavLink } from 'react-router-dom';
import { Home, ClipboardList, Map as MapIcon, Navigation } from 'lucide-react';
import clsx from 'clsx';

const Layout = () => {
  const navItems = [
    { to: '/', icon: Home, label: 'Inicio' },
    { to: '/logs', icon: ClipboardList, label: 'Registros' },
    { to: '/walks', icon: Navigation, label: 'Paseos' },
    { to: '/map', icon: MapIcon, label: 'Descanso' },
  ];

  return (
    <div className="flex flex-col min-h-screen pb-16 bg-slate-50">
      <header className="bg-white shadow-sm px-4 py-3 sticky top-0 z-10">
        <h1 className="text-xl font-bold text-slate-800">Camionero App</h1>
      </header>

      <main className="flex-grow p-4">
        <Outlet />
      </main>

      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex justify-around p-2 z-10 safe-area-bottom">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              clsx(
                'flex flex-col items-center p-2 rounded-lg min-w-[64px]',
                isActive ? 'text-blue-600 bg-blue-50' : 'text-slate-500 hover:text-slate-700'
              )
            }
          >
            <item.icon size={24} className="mb-1" />
            <span className="text-[10px] font-medium">{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default Layout;
