import { useState, useEffect, useRef } from 'react';
import { Play, Square, MapPin } from 'lucide-react';
import { MapContainer, TileLayer, Polyline, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icon in react-leaflet
// eslint-disable-next-line @typescript-eslint/no-explicit-any
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const Walks = () => {
  const [isTracking, setIsTracking] = useState(false);
  const [positions, setPositions] = useState<[number, number][]>([]);
  const [currentPosition, setCurrentPosition] = useState<[number, number] | null>(null);
  const watchIdRef = useRef<number | null>(null);

  useEffect(() => {
    // Get initial position
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentPosition([position.coords.latitude, position.coords.longitude]);
        },
        (error) => console.error("Error getting location:", error),
        { enableHighAccuracy: true }
      );
    }

    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  const handleStartTracking = () => {
    if (!('geolocation' in navigator)) {
      alert("Tu navegador no soporta geolocalización.");
      return;
    }

    setIsTracking(true);
    setPositions([]); // Reset path

    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const newPos: [number, number] = [position.coords.latitude, position.coords.longitude];
        setCurrentPosition(newPos);
        setPositions((prev) => [...prev, newPos]);
      },
      (error) => console.error("Error tracking location:", error),
      { enableHighAccuracy: true, maximumAge: 0 }
    );
  };

  const handleStopTracking = () => {
    setIsTracking(false);
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
  };

  return (
    <div className="space-y-6 h-full flex flex-col">
      <h2 className="text-2xl font-bold text-slate-800">Mis Paseos</h2>

      <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-100 flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-slate-800">Rastreo de Ruta</h3>
          <p className="text-sm text-slate-500">
            {isTracking ? 'Grabando tu paseo...' : 'Listo para iniciar'}
          </p>
        </div>
        
        {isTracking ? (
          <button 
            onClick={handleStopTracking}
            className="flex items-center gap-2 bg-red-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-red-600 transition-colors"
          >
            <Square size={18} />
            Detener
          </button>
        ) : (
          <button 
            onClick={handleStartTracking}
            className="flex items-center gap-2 bg-green-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-600 transition-colors"
          >
            <Play size={18} />
            Iniciar
          </button>
        )}
      </div>

      <div className="flex-grow bg-slate-200 rounded-xl overflow-hidden border border-slate-300 relative min-h-[300px]">
        {currentPosition ? (
          <MapContainer center={currentPosition} zoom={15} style={{ height: '100%', width: '100%' }}>
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {currentPosition && (
              <Marker position={currentPosition}>
                <Popup>Tu ubicación actual</Popup>
              </Marker>
            )}
            {positions.length > 1 && (
              <Polyline positions={positions} color="blue" weight={4} opacity={0.7} />
            )}
          </MapContainer>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center flex-col text-slate-500">
            <MapPin size={32} className="mb-2 opacity-50 animate-bounce" />
            <p>Obteniendo ubicación...</p>
          </div>
        )}
      </div>
      
      {positions.length > 0 && !isTracking && (
        <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 text-center">
          <p className="text-slate-700 font-medium">Paseo finalizado</p>
          <p className="text-sm text-slate-500">Puntos registrados: {positions.length}</p>
        </div>
      )}
    </div>
  );
};

export default Walks;
