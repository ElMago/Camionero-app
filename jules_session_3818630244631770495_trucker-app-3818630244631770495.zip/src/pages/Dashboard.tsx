import { Truck, Fuel, MapPin, Activity } from 'lucide-react';

const Dashboard = () => {
  // Mock data for the dashboard
  const stats = [
    { label: 'Km Hoy', value: '450 km', icon: Truck, color: 'text-blue-500', bg: 'bg-blue-100' },
    { label: 'Consumo', value: '28.5 L/100', icon: Fuel, color: 'text-orange-500', bg: 'bg-orange-100' },
    { label: 'Estado', value: 'En Ruta', icon: Activity, color: 'text-green-500', bg: 'bg-green-100' },
    { label: 'Destino', value: 'Madrid, ES', icon: MapPin, color: 'text-purple-500', bg: 'bg-purple-100' },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">Resumen Diario</h2>
      
      <div className="grid grid-cols-2 gap-4">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col items-center justify-center text-center">
            <div className={`p-3 rounded-full ${stat.bg} ${stat.color} mb-3`}>
              <stat.icon size={24} />
            </div>
            <p className="text-sm text-slate-500 font-medium">{stat.label}</p>
            <p className="text-lg font-bold text-slate-800 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-100">
        <h3 className="font-semibold text-slate-800 mb-4">Última Actividad</h3>
        <ul className="space-y-4">
          <li className="flex items-start">
            <div className="bg-blue-100 p-2 rounded-full mr-3 text-blue-600 mt-1">
              <Truck size={16} />
            </div>
            <div>
              <p className="text-slate-800 font-medium">Carga en Valencia</p>
              <p className="text-sm text-slate-500">Hoy, 08:30 AM</p>
            </div>
          </li>
          <li className="flex items-start">
            <div className="bg-orange-100 p-2 rounded-full mr-3 text-orange-600 mt-1">
              <Fuel size={16} />
            </div>
            <div>
              <p className="text-slate-800 font-medium">Repostaje</p>
              <p className="text-sm text-slate-500">Ayer, 18:45 PM • 300L</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;
