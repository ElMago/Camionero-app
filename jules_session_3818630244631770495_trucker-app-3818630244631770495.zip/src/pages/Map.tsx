import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Coffee, Navigation } from 'lucide-react';

// Fix for default marker icon in react-leaflet
// eslint-disable-next-line @typescript-eslint/no-explicit-any
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom icon for rest areas
const restAreaIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-orange.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Component to recenter map when location is found
function LocationMarker({ position }: { position: [number, number] | null }) {
  const map = useMap();
  
  useEffect(() => {
    if (position) {
      map.flyTo(position, 13);
    }
  }, [position, map]);

  return position === null ? null : (
    <Marker position={position}>
      <Popup>Estás aquí</Popup>
    </Marker>
  );
}

const MapView = () => {
  const [position, setPosition] = useState<[number, number] | null>(null);
  const [loadingLoc, setLoadingLoc] = useState(true);

  interface RestArea {
    id: number;
    lat: number;
    lng: number;
    name: string;
    amenities: string;
  }

  // Mock rest areas around a generic location or user's location
  const [restAreas, setRestAreas] = useState<RestArea[]>([]);

  const locateUser = () => {
    setLoadingLoc(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const newPos: [number, number] = [pos.coords.latitude, pos.coords.longitude];
          setPosition(newPos);
          setLoadingLoc(false);
          
          // Generate some mock rest areas near the user
          setRestAreas([
            { id: 1, lat: newPos[0] + 0.01, lng: newPos[1] + 0.01, name: 'Área de Servicio Norte', amenities: 'Gasolinera, Restaurante, Duchas' },
            { id: 2, lat: newPos[0] - 0.015, lng: newPos[1] - 0.005, name: 'Parking Camiones Sur', amenities: 'Seguridad 24h, Cafetería' },
            { id: 3, lat: newPos[0] + 0.005, lng: newPos[1] - 0.02, name: 'Descanso El Pinar', amenities: 'Zona verde, Mesas' },
          ]);
        },
        (err) => {
          console.error(err);
          setLoadingLoc(false);
          // Default to somewhere in Spain if location fails
          setPosition([40.4168, -3.7038]); 
        }
      );
    } else {
      setLoadingLoc(false);
    }
  };

  useEffect(() => {
    // Only locate user once on mount, don't call setState during render
    let isMounted = true;
    
    const doLocateUser = () => {
      if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            if (!isMounted) return;
            const newPos: [number, number] = [pos.coords.latitude, pos.coords.longitude];
            setPosition(newPos);
            setLoadingLoc(false);
            
            // Generate some mock rest areas near the user
            setRestAreas([
              { id: 1, lat: newPos[0] + 0.01, lng: newPos[1] + 0.01, name: 'Área de Servicio Norte', amenities: 'Gasolinera, Restaurante, Duchas' },
              { id: 2, lat: newPos[0] - 0.015, lng: newPos[1] - 0.005, name: 'Parking Camiones Sur', amenities: 'Seguridad 24h, Cafetería' },
              { id: 3, lat: newPos[0] + 0.005, lng: newPos[1] - 0.02, name: 'Descanso El Pinar', amenities: 'Zona verde, Mesas' },
            ]);
          },
          (err) => {
            if (!isMounted) return;
            console.error(err);
            setLoadingLoc(false);
            // Default to somewhere in Spain if location fails
            setPosition([40.4168, -3.7038]); 
          }
        );
      } else {
        if (isMounted) {
          setLoadingLoc(false);
        }
      }
    };

    doLocateUser();

    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div className="space-y-4 h-full flex flex-col">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Lugares de Descanso</h2>
        <button 
          onClick={locateUser}
          className="p-2 bg-white rounded-full shadow-sm border border-slate-200 text-blue-600 hover:bg-blue-50"
        >
          <Navigation size={20} />
        </button>
      </div>

      <div className="flex-grow bg-slate-200 rounded-xl overflow-hidden border border-slate-300 relative min-h-[400px]">
        {position ? (
          <MapContainer center={position} zoom={13} style={{ height: '100%', width: '100%' }}>
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            <LocationMarker position={position} />

            {restAreas.map((area) => (
              <Marker key={area.id} position={[area.lat, area.lng]} icon={restAreaIcon}>
                <Popup>
                  <div className="text-sm">
                    <strong className="block text-base mb-1">{area.name}</strong>
                    <div className="flex items-center gap-1 text-slate-600 mb-2">
                      <Coffee size={14} />
                      <span>{area.amenities}</span>
                    </div>
                    <button className="w-full bg-blue-600 text-white py-1 rounded text-xs font-medium">
                      Ver detalles
                    </button>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            {loadingLoc ? 'Buscando tu ubicación...' : 'Cargando mapa...'}
          </div>
        )}
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
        <h3 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
          <Coffee size={18} className="text-orange-500" />
          Cerca de ti
        </h3>
        {restAreas.length > 0 ? (
          <ul className="space-y-3">
            {restAreas.slice(0, 2).map((area) => (
              <li key={area.id} className="flex justify-between items-center border-b border-slate-100 pb-2 last:border-0 last:pb-0">
                <div>
                  <p className="font-medium text-slate-800 text-sm">{area.name}</p>
                  <p className="text-xs text-slate-500">{area.amenities}</p>
                </div>
                <button className="text-blue-600 text-xs font-medium bg-blue-50 px-2 py-1 rounded">Ruta</button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-slate-500 italic">No se encontraron lugares de descanso cerca.</p>
        )}
      </div>
    </div>
  );
};

export default MapView;
