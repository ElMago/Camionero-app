import { useState } from 'react';
import { PackagePlus, Fuel, Route } from 'lucide-react';

const Logs = () => {
  const [activeTab, setActiveTab] = useState('carga');

  const tabs = [
    { id: 'carga', label: 'Carga/Descarga', icon: PackagePlus },
    { id: 'combustible', label: 'Repostaje', icon: Fuel },
    { id: 'kilometros', label: 'Kilómetros', icon: Route },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">Nuevos Registros</h2>

      <div className="flex bg-white rounded-lg p-1 border border-slate-200">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 flex flex-col items-center py-2 px-1 rounded-md text-sm transition-colors ${
              activeTab === tab.id
                ? 'bg-blue-50 text-blue-700 font-medium shadow-sm'
                : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'
            }`}
          >
            <tab.icon size={18} className="mb-1" />
            <span className="text-[11px] leading-tight text-center">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-100">
        {activeTab === 'carga' && (
          <form className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Tipo de Operación</label>
              <div className="flex gap-4">
                <label className="flex items-center">
                  <input type="radio" name="operation" value="carga" className="text-blue-600 focus:ring-blue-500" defaultChecked />
                  <span className="ml-2 text-slate-700">Carga</span>
                </label>
                <label className="flex items-center">
                  <input type="radio" name="operation" value="descarga" className="text-blue-600 focus:ring-blue-500" />
                  <span className="ml-2 text-slate-700">Descarga</span>
                </label>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">País</label>
                <select className="w-full border-slate-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2.5 border">
                  <option>España (ES)</option>
                  <option>Francia (FR)</option>
                  <option>Portugal (PT)</option>
                  <option>Alemania (DE)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Pueblo / Ciudad</label>
                <input type="text" className="w-full border-slate-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border" placeholder="Ej. Valencia" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Mercancía (Opcional)</label>
              <input type="text" className="w-full border-slate-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border" placeholder="Ej. Palets de fruta" />
            </div>

            <button type="button" className="w-full bg-blue-600 text-white font-medium py-3 rounded-lg hover:bg-blue-700 transition-colors mt-2">
              Guardar Registro
            </button>
          </form>
        )}

        {activeTab === 'combustible' && (
          <form className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Litros</label>
                <input type="number" step="0.1" className="w-full border-slate-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border" placeholder="0.00" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Importe (€)</label>
                <input type="number" step="0.01" className="w-full border-slate-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border" placeholder="0.00" />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Odómetro (Km)</label>
              <input type="number" className="w-full border-slate-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border" placeholder="Ej. 154000" />
            </div>

            <button type="button" className="w-full bg-orange-500 text-white font-medium py-3 rounded-lg hover:bg-orange-600 transition-colors mt-2">
              Guardar Repostaje
            </button>
          </form>
        )}

        {activeTab === 'kilometros' && (
          <form className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Fecha</label>
              <input type="date" className="w-full border-slate-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border" defaultValue={new Date().toISOString().split('T')[0]} />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Km Inicio</label>
                <input type="number" className="w-full border-slate-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Km Fin</label>
                <input type="number" className="w-full border-slate-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-2 border" />
              </div>
            </div>

            <button type="button" className="w-full bg-slate-800 text-white font-medium py-3 rounded-lg hover:bg-slate-900 transition-colors mt-2">
              Registrar Jornada
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default Logs;
